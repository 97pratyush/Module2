import { AddEmployeeComponent } from './add-employee.component';
import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AddEmployeeCanDeactivateRouteGuardService implements CanDeactivate<AddEmployeeComponent> {

  canDeactivate(component: AddEmployeeComponent): boolean {
    if(component.createEmployeeForm.dirty) {
      return confirm("Data will be discarded, are you sure to move?");
    }
    return true;
  }
  constructor() { }
  }
