import { AddEmployeeCanDeactivateRouteGuardService } from './employee/add-employee-can-deactivate-route-guard.service';
import { SearchEmployeeComponent } from './employee/search-employee.component';
import { EmployeeComponent } from './employee/employee.component';
import { HomeComponent } from './employee/home.component';
import { AddEmployeeComponent } from './employee/add-employee.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanDeactivate } from '@angular/router';


const routes: Routes = [
  { path: "employees", component: EmployeeListComponent },
  { path: "add", component: AddEmployeeComponent, canDeactivate: [AddEmployeeCanDeactivateRouteGuardService] },
  { path: "employees/:id", component: EmployeeComponent },
  { path: "search", component: SearchEmployeeComponent },
  { path: '', component: HomeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
