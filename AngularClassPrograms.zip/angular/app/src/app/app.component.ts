import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validator, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  // title = 'app';
  // imagePath = '../assets/cat.jpg';
  // name = 'Tom';
  // day = 3;
  // content = 'Hello World!';



  // process() {
  //   alert('Welcome');
  // }
  // processData(event) {
  //   this.name = event.target.value;
  // }
  // processForm(value: any) {
  //   console.log(value);
  // }

  // userForm: FormGroup = new FormGroup({
  //   name: new FormControl(null, [Validators.required, Validators.minLength(4), Validators.maxLength(20)]),
  //   email: new FormControl(),

  //   address: new FormGroup({
  //     street: new FormControl,
  //     city: new FormControl(),
  //     pincode: new FormControl(null,[Validators.pattern("[1-9][0-9]{5}")])
  //   })

  // });



  userForm: FormGroup;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.userForm = this.formBuilder.group({
      name: ['Pratyush', [Validators.required, Validators.minLength(4), Validators.maxLength(20)]],
      email: [],
      address: this.formBuilder.group({
        street: [],
        city: [],
        pincode: [null, Validators.pattern("[1-9][0-9]{5}")]
      })
    })
  }



  process() {
    console.log(this.userForm.value);
  }

}
