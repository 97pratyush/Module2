import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';
import { IEmployee } from './employee.interface';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
})

export class EmployeeListComponent implements OnInit {

  selectedRadioButtonValue = 'all';
  searchTerm: string;
  employees: IEmployee[];

  constructor(private employeeService: EmployeeService) { }

  getAllEmployeesCount(): number {
    return this.employees.length;
  }

  getMaleEmployeesCount(): number {
    return this.employees.filter(e => e.gender === 'Male').length;
  }

  getFemaleEmployeesCount(): number {
    return this.employees.filter(e => e.gender === 'Female').length;
  }

  onRadioButtonValueChange(value: string) {
    this.selectedRadioButtonValue = value;
  }

  ngOnInit() {
    this.employees = this.employeeService.getEmployees();
   }
}
