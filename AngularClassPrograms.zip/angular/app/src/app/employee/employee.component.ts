import { IEmployee } from './employee.interface';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  employee: IEmployee = {
     code: 'a001',
     name: 'Sara',
     gender: 'Female',
     annualSalary: 450000,
     dateOfBirth: '12/12/1997'
};
constructor() { }

ngOnInit() {
}

}
